#include "main.h"

int main()
{
    probrarIngresarYMostrarProd();

    return 0;
}


void probrarIngresarYMostrarProd(void)
{
    tProd   prod;
    int     cant = 0;

    puts("Probando ingresar productos y mostrarlos\n"
         "======== ======== ========= = ==========");

    if(ingresarProducto(&prod))
        mostrarProducto(NULL);
    do
    {
        mostrarProducto(&prod);
        cant++;
    }while(ingresarProducto(&prod));

    fprintf(stdout, "Se mostraron %d productos.\n\n", cant);
}












/*
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int ID;
    char nombre[50];
    int cantidad;
    float precio;
}tProducto;



int main()
{
    FILE *fp;







    tProducto p;
    int i=0;


    fp = fopen("maestro.bin", "rb");

    //fread(&p,sizeof(tProducto),1,fp);

    while(!feof(fp))
    {


        p.ID=i++;
        printf("Nombre: ");
        fflush(stdin);
        gets(p.nombre);

        printf("Cantidad: ");
        scanf("%d",&p.cantidad);
        printf("Precio: ");
        scanf("%f",&p.precio);

        fwrite(&p,sizeof(tProducto),1, fp);



        printf("%d - %s - %d - %.2f\n", p.ID, p.nombre, p.cantidad, p.precio);

        fread(&p,sizeof(tProducto),1,fp);



    }

    fclose(fp);
    return 0;
}
*/
