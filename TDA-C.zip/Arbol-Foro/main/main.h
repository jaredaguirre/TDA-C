#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#include "../productos/productos.h"


void probrarIngresarYMostrarProd(void);

#endif // MAIN_H_INCLUDED
